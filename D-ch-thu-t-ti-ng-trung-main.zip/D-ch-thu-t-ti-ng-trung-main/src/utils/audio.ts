// Audio player utility supporting both server Gemini TTS and browser Web Speech API

let currentAudio: HTMLAudioElement | null = null;

export async function playMandarinTTS(text: string, rate: number = 1.0): Promise<void> {
  // Stop any currently playing audio
  stopAudio();

  // Try server Gemini TTS first for natural AI voice
  try {
    const res = await fetch('/api/tts', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ text, voice: 'Kore' }),
    });

    if (res.ok) {
      const contentType = res.headers.get('content-type') || '';
      if (contentType.includes('application/json')) {
        const data = await res.json().catch(() => ({}));
        if (data.audioBase64) {
          const audioUrl = `data:audio/wav;base64,${data.audioBase64}`;
          currentAudio = new Audio(audioUrl);
          currentAudio.playbackRate = rate;
          await currentAudio.play();
          return;
        }
      }
    }
  } catch (err) {
    console.warn('Gemini TTS failed, falling back to Web Speech API:', err);
  }

  // Fallback to browser SpeechSynthesis
  return playBrowserSpeech(text, rate);
}

export function playBrowserSpeech(text: string, rate: number = 1.0): Promise<void> {
  return new Promise((resolve) => {
    if (!('speechSynthesis' in window)) {
      resolve();
      return;
    }

    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.lang = 'zh-CN';
    utterance.rate = rate;

    // Pick Chinese voice if available
    const voices = window.speechSynthesis.getVoices();
    const zhVoice = voices.find((v) => v.lang.startsWith('zh') || v.lang.includes('cmn'));
    if (zhVoice) {
      utterance.voice = zhVoice;
    }

    utterance.onend = () => resolve();
    utterance.onerror = () => resolve();

    window.speechSynthesis.speak(utterance);
  });
}

export function stopAudio(): void {
  if (currentAudio) {
    currentAudio.pause();
    currentAudio.currentTime = 0;
    currentAudio = null;
  }
  if ('speechSynthesis' in window) {
    window.speechSynthesis.cancel();
  }
}
