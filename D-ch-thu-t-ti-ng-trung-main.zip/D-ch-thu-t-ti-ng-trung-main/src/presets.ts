export interface PresetItem {
  id: string;
  title: string;
  category: 'basic' | 'polyphone' | 'idiom' | 'slang' | 'dialogue' | 'traditional' | 'poetry' | 'single_word';
  description: string;
  chinese: string;
}

export const PRESETS: PresetItem[] = [
  {
    id: 'basic-intro',
    title: 'Chào hỏi & Giao tiếp',
    category: 'basic',
    description: 'Ví dụ mẫu chuẩn trong quy tắc đối chiếu từng câu',
    chinese: '你好，很高兴认识你。请问你是第一次来中国吗？如果是的话，祝你旅途愉快！',
  },
  {
    id: 'polyphone-sandhi',
    title: 'Đa âm từ & Biến điệu',
    category: 'polyphone',
    description: 'Chữ đa âm (行, 得, 还, 便) và quy tắc biến điệu 不, 一, thanh 3',
    chinese: '他去银行走了一行路。你得好好工作才能得到大家的认可。这件衣服不但便宜，而且方便出行。',
  },
  {
    id: 'idioms-chengyu',
    title: 'Thành ngữ tứ tự (成语)',
    category: 'idiom',
    description: 'Bốn thành ngữ phổ biến giải thích nghĩa đen và nghĩa bóng thực tế',
    chinese: '亡羊补牢，为时不晚。我们做事千万不要画蛇添足，也不要守株待兔，要懂得入乡随俗。',
  },
  {
    id: 'internet-slang',
    title: 'Lóng mạng & Giới trẻ',
    category: 'slang',
    description: 'Từ vựng mạng hiện đại: YYDS, 破防, 打工人, 躺平',
    chinese: '这家火锅店的味道简直是YYDS！看到这个感人的故事我瞬间破防了。加油吧，努力的打工人！',
  },
  {
    id: 'business-dialogue',
    title: 'Hội thoại công sở',
    category: 'dialogue',
    description: 'Hội thoại đàm phán hợp đồng giữa Giám đốc Lý và Vương Minh',
    chinese: `李经理：王先生，您好！关于这次项目的合作合同，贵公司审阅得怎么样了？
王先生：李经理好！我们法务部门已经详细看过了，整体条款都很满意，下周一就可以正式签约。
李经理：太好了！期待我们合作愉快，互利共赢。`,
  },
  {
    id: 'traditional-script',
    title: 'Chữ Phồn thể (繁體字)',
    category: 'traditional',
    description: 'Văn bản phồn thể giữ nguyên chữ Hán, phiên âm Mandarin',
    chinese: '歡迎來到台灣！這家珍珠奶茶店的手工茶葉非常有名，味道濃郁，請慢慢品嚐。',
  },
  {
    id: 'classical-tang-poem',
    title: 'Thơ cổ Đường thi',
    category: 'poetry',
    description: 'Bài thơ Tĩnh Dạ Tứ (Lý Bạch) phiên âm từng câu đối chiếu',
    chinese: `床前明月光，
疑是地上霜。
举头望明月，
低头思故乡。`,
  },
  {
    id: 'single-vocab',
    title: 'Từ đơn & Câu ngắn',
    category: 'single_word',
    description: 'Tra cứu ngắn gọn theo bảng từ vựng',
    chinese: '学习 工作 朋友 咖啡 手机',
  },
];
