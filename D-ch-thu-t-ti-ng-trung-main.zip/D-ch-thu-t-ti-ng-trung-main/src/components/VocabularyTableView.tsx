import React, { useState } from 'react';
import {
  Volume2,
  BookmarkPlus,
  BookmarkCheck,
  Search,
  ExternalLink,
  Sparkles,
  Download,
  Filter,
} from 'lucide-react';
import { VocabularyItem, SavedWord } from '../types';
import { playMandarinTTS } from '../utils/audio';

interface VocabularyTableViewProps {
  vocabulary: VocabularyItem[];
  onInspectWord: (word: string) => void;
  onSaveWord: (word: SavedWord) => void;
  isWordSaved: (chinese: string) => boolean;
  audioRate: number;
}

export const VocabularyTableView: React.FC<VocabularyTableViewProps> = ({
  vocabulary,
  onInspectWord,
  onSaveWord,
  isWordSaved,
  audioRate,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedHsk, setSelectedHsk] = useState('all');

  const filtered = vocabulary.filter((item) => {
    const matchesSearch =
      item.chinese.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.pinyin.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.hanViet.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.meaning.toLowerCase().includes(searchTerm.toLowerCase());

    const matchesHsk =
      selectedHsk === 'all' || (item.hskLevel && item.hskLevel.includes(selectedHsk));

    return matchesSearch && matchesHsk;
  });

  const handleExportCsv = () => {
    const header = 'Tiếng Trung,Pinyin,Âm Hán Việt,Nghĩa tiếng Việt,Từ loại,Cấp HSK\n';
    const rows = filtered
      .map(
        (v) =>
          `"${v.chinese}","${v.pinyin}","${v.hanViet}","${v.meaning.replace(/"/g, '""')}","${v.partOfSpeech}","${v.hskLevel || ''}"`
      )
      .join('\n');
    const blob = new Blob(['\uFEFF' + header + rows], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `tu-vung-tieng-trung-${Date.now()}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-4">
      {/* Search and filters bar */}
      <div className="bg-white p-3.5 rounded-2xl border border-stone-200/90 shadow-2xs flex flex-wrap items-center justify-between gap-3 text-xs">
        <div className="flex items-center gap-2 flex-1 min-w-[200px]">
          <div className="relative w-full max-w-xs">
            <Search className="w-3.5 h-3.5 text-stone-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Tìm theo chữ Hán, Pinyin, Hán Việt hoặc Nghĩa..."
              className="w-full pl-8 pr-3 py-1.5 rounded-lg border border-stone-200 bg-stone-50/50 text-stone-900 placeholder:text-stone-400 focus:outline-hidden focus:border-red-500 focus:bg-white text-xs"
            />
          </div>
        </div>

        <div className="flex items-center gap-2">
          {/* HSK Filter */}
          <div className="flex items-center gap-1 text-stone-600">
            <Filter className="w-3.5 h-3.5 text-stone-400" />
            <select
              value={selectedHsk}
              onChange={(e) => setSelectedHsk(e.target.value)}
              className="bg-stone-50 border border-stone-200 rounded-lg px-2 py-1 text-xs font-medium text-stone-700 focus:outline-hidden"
            >
              <option value="all">Tất cả cấp độ</option>
              <option value="HSK 1">HSK 1</option>
              <option value="HSK 2">HSK 2</option>
              <option value="HSK 3">HSK 3</option>
              <option value="HSK 4">HSK 4</option>
              <option value="HSK 5">HSK 5</option>
              <option value="HSK 6">HSK 6</option>
            </select>
          </div>

          {/* Export CSV button */}
          <button
            type="button"
            onClick={handleExportCsv}
            className="inline-flex items-center gap-1 px-3 py-1.5 rounded-lg bg-stone-100 hover:bg-stone-200/80 text-stone-700 font-medium transition-colors"
            title="Tải bảng từ vựng dạng file CSV"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Xuất CSV</span>
          </button>
        </div>
      </div>

      {/* Main Table Container */}
      <div className="bg-white rounded-2xl border border-stone-200/90 shadow-2xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-sm border-collapse">
            <thead>
              <tr className="bg-stone-100/70 border-b border-stone-200 text-stone-700 text-xs font-bold uppercase tracking-wider">
                <th className="py-3 px-4">Tiếng Trung</th>
                <th className="py-3 px-4">Pinyin</th>
                <th className="py-3 px-4">Âm Hán Việt</th>
                <th className="py-3 px-4">Nghĩa tiếng Việt</th>
                <th className="py-3 px-4">Từ loại</th>
                <th className="py-3 px-4">Cấp độ</th>
                <th className="py-3 px-4 text-right">Thao tác</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-stone-100">
              {filtered.length > 0 ? (
                filtered.map((item, idx) => {
                  const saved = isWordSaved(item.chinese);

                  return (
                    <tr
                      key={idx}
                      className="hover:bg-red-50/40 transition-colors group"
                    >
                      {/* Tiếng Trung */}
                      <td className="py-3.5 px-4">
                        <div className="flex items-center gap-2">
                          <span
                            onClick={() => onInspectWord(item.chinese)}
                            className="text-lg font-chinese font-semibold text-stone-900 cursor-pointer hover:text-red-700 group-hover:underline underline-offset-4"
                            title="Nhấp để tra cứu chi tiết chữ Hán"
                          >
                            {item.chinese}
                          </span>
                        </div>
                      </td>

                      {/* Pinyin */}
                      <td className="py-3.5 px-4 font-medium text-red-700 font-sans">
                        {item.pinyin}
                      </td>

                      {/* Âm Hán Việt */}
                      <td className="py-3.5 px-4 font-semibold text-amber-800">
                        {item.hanViet}
                      </td>

                      {/* Nghĩa tiếng Việt */}
                      <td className="py-3.5 px-4 text-stone-800">
                        <div>{item.meaning}</div>
                        {item.exampleSentence && (
                          <div className="text-xs text-stone-500 mt-1 font-chinese">
                            Ví dụ: {item.exampleSentence}{' '}
                            <span className="font-sans text-stone-400">
                              ({item.exampleMeaning})
                            </span>
                          </div>
                        )}
                      </td>

                      {/* Từ loại */}
                      <td className="py-3.5 px-4 text-stone-500 text-xs">
                        <span className="px-2 py-0.5 rounded-md bg-stone-100 text-stone-700 border border-stone-200">
                          {item.partOfSpeech}
                        </span>
                      </td>

                      {/* Cấp độ */}
                      <td className="py-3.5 px-4 text-xs font-semibold">
                        {item.hskLevel ? (
                          <span className="px-2 py-0.5 rounded-md bg-red-50 text-red-700 border border-red-200">
                            {item.hskLevel}
                          </span>
                        ) : (
                          <span className="text-stone-400">-</span>
                        )}
                      </td>

                      {/* Thao tác */}
                      <td className="py-3.5 px-4 text-right">
                        <div className="flex items-center justify-end gap-1.5">
                          {/* Listen */}
                          <button
                            type="button"
                            onClick={() => playMandarinTTS(item.chinese, audioRate)}
                            className="p-1.5 text-stone-500 hover:text-stone-900 hover:bg-stone-100 rounded-lg transition-colors"
                            title="Nghe phát âm"
                          >
                            <Volume2 className="w-4 h-4" />
                          </button>

                          {/* Save Word */}
                          <button
                            type="button"
                            onClick={() =>
                              onSaveWord({
                                id: `${item.chinese}-${Date.now()}`,
                                chinese: item.chinese,
                                pinyin: item.pinyin,
                                hanViet: item.hanViet,
                                meaning: item.meaning,
                                partOfSpeech: item.partOfSpeech,
                                hskLevel: item.hskLevel || undefined,
                                createdAt: Date.now(),
                              })
                            }
                            className={`p-1.5 rounded-lg transition-colors ${
                              saved
                                ? 'text-amber-600 bg-amber-50'
                                : 'text-stone-400 hover:text-amber-600 hover:bg-stone-100'
                            }`}
                            title={saved ? 'Đã lưu trong Sổ từ vựng' : 'Lưu vào Sổ từ vựng'}
                          >
                            {saved ? (
                              <BookmarkCheck className="w-4 h-4" />
                            ) : (
                              <BookmarkPlus className="w-4 h-4" />
                            )}
                          </button>

                          {/* Inspect Word */}
                          <button
                            type="button"
                            onClick={() => onInspectWord(item.chinese)}
                            className="p-1.5 text-stone-400 hover:text-red-700 hover:bg-stone-100 rounded-lg transition-colors"
                            title="Tra cứu từ điển sâu"
                          >
                            <ExternalLink className="w-4 h-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })
              ) : (
                <tr>
                  <td colSpan={7} className="py-8 text-center text-stone-400 text-xs">
                    Không tìm thấy từ vựng phù hợp với bộ lọc.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
