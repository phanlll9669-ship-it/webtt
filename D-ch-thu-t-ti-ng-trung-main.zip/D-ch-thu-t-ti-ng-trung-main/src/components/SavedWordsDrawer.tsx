import React, { useState } from 'react';
import {
  X,
  Trash2,
  Volume2,
  Search,
  ExternalLink,
  BookOpen,
  Sparkles,
  RotateCw,
  Download,
} from 'lucide-react';
import { SavedWord } from '../types';
import { playMandarinTTS } from '../utils/audio';

interface SavedWordsDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  savedWords: SavedWord[];
  onRemoveWord: (chinese: string) => void;
  onInspectWord: (chinese: string) => void;
  audioRate: number;
}

export const SavedWordsDrawer: React.FC<SavedWordsDrawerProps> = ({
  isOpen,
  onClose,
  savedWords,
  onRemoveWord,
  onInspectWord,
  audioRate,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [isFlashcardMode, setIsFlashcardMode] = useState(false);
  const [currentCardIndex, setCurrentCardIndex] = useState(0);
  const [isFlipped, setIsFlipped] = useState(false);

  if (!isOpen) return null;

  const filteredWords = savedWords.filter(
    (w) =>
      w.chinese.toLowerCase().includes(searchTerm.toLowerCase()) ||
      w.pinyin.toLowerCase().includes(searchTerm.toLowerCase()) ||
      w.hanViet.toLowerCase().includes(searchTerm.toLowerCase()) ||
      w.meaning.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const currentCard = filteredWords[currentCardIndex];

  return (
    <div className="fixed inset-0 z-50 flex justify-end bg-stone-900/40 backdrop-blur-xs">
      <div
        className="w-full max-w-md bg-white h-full shadow-2xl flex flex-col border-l border-stone-200"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="p-4 border-b border-stone-200 flex items-center justify-between bg-stone-50/70">
          <div className="flex items-center gap-2">
            <span className="font-bold text-stone-900 text-base">Sổ Từ Vựng Đã Lưu</span>
            <span className="text-xs px-2 py-0.5 rounded-full bg-amber-100 text-amber-900 font-semibold">
              {savedWords.length} từ
            </span>
          </div>
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => {
                setIsFlashcardMode(!isFlashcardMode);
                setIsFlipped(false);
              }}
              className={`px-2.5 py-1 rounded-lg text-xs font-semibold transition-colors ${
                isFlashcardMode
                  ? 'bg-red-600 text-white'
                  : 'bg-white border border-stone-200 text-stone-700 hover:bg-stone-100'
              }`}
            >
              {isFlashcardMode ? 'Thoát Flashcard' : 'Luyện Flashcard'}
            </button>
            <button
              onClick={onClose}
              className="p-1.5 text-stone-400 hover:text-stone-700 rounded-lg"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Content */}
        {isFlashcardMode ? (
          // Flashcard Mode
          <div className="p-6 flex-1 flex flex-col items-center justify-center space-y-6">
            {filteredWords.length > 0 && currentCard ? (
              <>
                <div className="text-xs text-stone-400 font-medium">
                  Thẻ {currentCardIndex + 1} / {filteredWords.length}
                </div>

                {/* Flip Card */}
                <div
                  onClick={() => setIsFlipped(!isFlipped)}
                  className="w-full h-72 bg-gradient-to-br from-stone-50 to-amber-50/30 rounded-3xl border-2 border-dashed border-stone-300 p-6 flex flex-col items-center justify-center text-center cursor-pointer shadow-xs hover:border-red-400 transition-all select-none relative group"
                >
                  <span className="absolute top-4 right-4 text-[11px] text-stone-400 flex items-center gap-1">
                    <RotateCw className="w-3.5 h-3.5" /> Chạm để lật
                  </span>

                  {!isFlipped ? (
                    <div className="space-y-4">
                      <div className="text-6xl font-chinese font-bold text-stone-900">
                        {currentCard.chinese}
                      </div>
                      <div className="text-xs text-stone-400">
                        (Nhớ lại Pinyin, Hán Việt và Nghĩa)
                      </div>
                    </div>
                  ) : (
                    <div className="space-y-3">
                      <div className="text-3xl font-chinese font-bold text-stone-900">
                        {currentCard.chinese}
                      </div>
                      <div className="text-xl font-sans font-bold text-red-700">
                        {currentCard.pinyin}
                      </div>
                      <div className="text-xs font-semibold text-amber-800 bg-amber-100 px-3 py-1 rounded-full inline-block">
                        Hán Việt: {currentCard.hanViet}
                      </div>
                      <p className="text-sm font-medium text-stone-800 pt-2">
                        {currentCard.meaning}
                      </p>
                    </div>
                  )}
                </div>

                {/* Controls */}
                <div className="flex items-center gap-3">
                  <button
                    type="button"
                    onClick={() => {
                      setIsFlipped(false);
                      setCurrentCardIndex((prev) =>
                        prev > 0 ? prev - 1 : filteredWords.length - 1
                      );
                    }}
                    className="px-4 py-2 rounded-xl border border-stone-200 text-xs font-semibold text-stone-700 hover:bg-stone-50"
                  >
                    Thẻ trước
                  </button>

                  <button
                    type="button"
                    onClick={() => playMandarinTTS(currentCard.chinese, audioRate)}
                    className="p-2.5 rounded-xl bg-red-600 text-white shadow-xs hover:bg-red-700"
                    title="Nghe phát âm"
                  >
                    <Volume2 className="w-4 h-4" />
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      setIsFlipped(false);
                      setCurrentCardIndex((prev) =>
                        prev < filteredWords.length - 1 ? prev + 1 : 0
                      );
                    }}
                    className="px-4 py-2 rounded-xl bg-stone-900 text-white text-xs font-semibold hover:bg-stone-800"
                  >
                    Thẻ kế tiếp
                  </button>
                </div>
              </>
            ) : (
              <div className="text-center text-stone-400 text-sm">
                Chưa có từ vựng nào trong danh sách.
              </div>
            )}
          </div>
        ) : (
          // Regular List Mode
          <div className="flex-1 flex flex-col overflow-hidden">
            {/* Search */}
            <div className="p-3 border-b border-stone-100">
              <div className="relative">
                <Search className="w-3.5 h-3.5 text-stone-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  placeholder="Lọc từ trong sổ..."
                  className="w-full pl-8 pr-3 py-1.5 rounded-lg border border-stone-200 bg-stone-50/50 text-xs focus:outline-hidden focus:bg-white"
                />
              </div>
            </div>

            {/* List */}
            <div className="flex-1 overflow-y-auto p-4 space-y-2.5">
              {filteredWords.length > 0 ? (
                filteredWords.map((item) => (
                  <div
                    key={item.id}
                    className="p-3 bg-stone-50/70 rounded-xl border border-stone-200/80 flex items-center justify-between hover:border-stone-300 transition-colors"
                  >
                    <div className="space-y-0.5">
                      <div className="flex items-center gap-2">
                        <span
                          onClick={() => onInspectWord(item.chinese)}
                          className="font-chinese font-bold text-stone-900 text-base cursor-pointer hover:text-red-700"
                        >
                          {item.chinese}
                        </span>
                        <span className="font-sans text-xs font-semibold text-red-700">
                          {item.pinyin}
                        </span>
                        <span className="text-[11px] text-amber-800 font-medium">
                          ({item.hanViet})
                        </span>
                      </div>
                      <p className="text-xs text-stone-700">{item.meaning}</p>
                    </div>

                    <div className="flex items-center gap-1">
                      <button
                        type="button"
                        onClick={() => playMandarinTTS(item.chinese, audioRate)}
                        className="p-1.5 text-stone-400 hover:text-stone-800 rounded"
                        title="Nghe phát âm"
                      >
                        <Volume2 className="w-3.5 h-3.5" />
                      </button>
                      <button
                        type="button"
                        onClick={() => onRemoveWord(item.chinese)}
                        className="p-1.5 text-stone-400 hover:text-red-600 rounded"
                        title="Xóa khỏi sổ từ"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                ))
              ) : (
                <div className="py-12 text-center text-stone-400 text-xs">
                  {savedWords.length === 0
                    ? 'Bạn chưa lưu từ vựng nào. Hãy nhấp biểu tượng dấu trang để lưu từ.'
                    : 'Không tìm thấy từ vựng khớp với tìm kiếm.'}
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
