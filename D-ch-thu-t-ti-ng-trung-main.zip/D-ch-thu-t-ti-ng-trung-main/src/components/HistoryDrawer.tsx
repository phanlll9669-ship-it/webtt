import React from 'react';
import { X, Trash2, Clock, ArrowRight, ExternalLink } from 'lucide-react';
import { TranslationHistoryItem } from '../types';

interface HistoryDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  history: TranslationHistoryItem[];
  onSelectHistory: (item: TranslationHistoryItem) => void;
  onClearHistory: () => void;
}

export const HistoryDrawer: React.FC<HistoryDrawerProps> = ({
  isOpen,
  onClose,
  history,
  onSelectHistory,
  onClearHistory,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex justify-end bg-stone-900/40 backdrop-blur-xs">
      <div
        className="w-full max-w-md bg-white h-full shadow-2xl flex flex-col border-l border-stone-200"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="p-4 border-b border-stone-200 flex items-center justify-between bg-stone-50/70">
          <div className="flex items-center gap-2">
            <span className="font-bold text-stone-900 text-base">Lịch Sử Tra Dịch</span>
            <span className="text-xs px-2 py-0.5 rounded-full bg-stone-200 text-stone-700 font-semibold">
              {history.length}
            </span>
          </div>
          <div className="flex items-center gap-2">
            {history.length > 0 && (
              <button
                type="button"
                onClick={onClearHistory}
                className="text-xs text-stone-500 hover:text-red-600 transition-colors"
              >
                Xóa lịch sử
              </button>
            )}
            <button
              onClick={onClose}
              className="p-1.5 text-stone-400 hover:text-stone-700 rounded-lg"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* List */}
        <div className="flex-1 overflow-y-auto p-4 space-y-3">
          {history.length > 0 ? (
            history.map((item) => (
              <div
                key={item.id}
                onClick={() => {
                  onSelectHistory(item);
                  onClose();
                }}
                className="p-3.5 bg-stone-50/70 hover:bg-red-50/40 rounded-xl border border-stone-200/80 hover:border-red-300 transition-all cursor-pointer space-y-1.5 group"
              >
                <div className="flex items-center justify-between text-xs text-stone-400">
                  <div className="flex items-center gap-1">
                    <Clock className="w-3 h-3" />
                    <span>{new Date(item.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                  </div>
                  <span className="px-1.5 py-0.5 rounded bg-stone-200/60 text-stone-600 text-[10px] font-semibold">
                    {item.sentencesCount} câu
                  </span>
                </div>

                {/* Chinese snippet */}
                <div className="text-sm font-chinese font-semibold text-stone-900 line-clamp-2 group-hover:text-red-700 transition-colors">
                  {item.input}
                </div>

                {/* Vietnamese snippet */}
                <div className="text-xs text-stone-600 line-clamp-1">
                  {item.overallVietnamese}
                </div>
              </div>
            ))
          ) : (
            <div className="py-16 text-center text-stone-400 text-xs">
              Chưa có lịch sử dịch nào được lưu.
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
