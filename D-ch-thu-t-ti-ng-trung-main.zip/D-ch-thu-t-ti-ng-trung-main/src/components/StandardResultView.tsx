import React, { useState } from 'react';
import {
  Copy,
  Check,
  Volume2,
  VolumeX,
  Share2,
  ExternalLink,
  Info,
  BookmarkPlus,
  BookmarkCheck,
} from 'lucide-react';
import { SentenceItem, Token, SavedWord } from '../types';
import { playMandarinTTS, stopAudio } from '../utils/audio';

interface StandardResultViewProps {
  sentences: SentenceItem[];
  overallVietnamese: string;
  onInspectWord: (word: string, contextSentence?: string) => void;
  onSaveWord: (word: SavedWord) => void;
  isWordSaved: (chinese: string) => boolean;
  audioRate: number;
}

export const StandardResultView: React.FC<StandardResultViewProps> = ({
  sentences,
  overallVietnamese,
  onInspectWord,
  onSaveWord,
  isWordSaved,
  audioRate,
}) => {
  const [copiedIndex, setCopiedIndex] = useState<number | null>(null);
  const [copiedPart, setCopiedPart] = useState<string | null>(null);
  const [playingIndex, setPlayingIndex] = useState<number | null>(null);

  const handleCopySentence = async (sentence: SentenceItem, index: number) => {
    const formatted = `Tiếng Trung:
${sentence.chinese}

Pinyin:
${sentence.pinyin}

Tiếng Việt:
${sentence.vietnamese}`;

    await navigator.clipboard.writeText(formatted);
    setCopiedIndex(index);
    setTimeout(() => setCopiedIndex(null), 2000);
  };

  const handleCopyPart = async (text: string, partKey: string) => {
    await navigator.clipboard.writeText(text);
    setCopiedPart(partKey);
    setTimeout(() => setCopiedPart(null), 1800);
  };

  const handlePlaySentence = async (text: string, index: number) => {
    if (playingIndex === index) {
      stopAudio();
      setPlayingIndex(null);
      return;
    }
    setPlayingIndex(index);
    try {
      await playMandarinTTS(text, audioRate);
    } finally {
      setPlayingIndex(null);
    }
  };

  return (
    <div className="space-y-6">
      {/* Sentences List */}
      <div className="space-y-4">
        {sentences.map((item, idx) => {
          const isCopied = copiedIndex === item.index;
          const isPlaying = playingIndex === item.index;
          const showNumbering = sentences.length > 1;

          return (
            <div
              key={item.index}
              className="bg-white rounded-2xl border border-stone-200/90 shadow-2xs overflow-hidden transition-all hover:border-stone-300"
            >
              {/* Sentence Header Card */}
              <div className="px-5 py-3 bg-stone-50/70 border-b border-stone-200/70 flex items-center justify-between">
                <div className="flex items-center gap-2.5">
                  {showNumbering && (
                    <span className="w-6 h-6 rounded-md bg-stone-200 text-stone-700 font-bold text-xs flex items-center justify-center">
                      {item.index}
                    </span>
                  )}
                  {item.speaker && (
                    <span className="px-2.5 py-0.5 rounded-full text-xs font-semibold bg-red-100 text-red-800 border border-red-200">
                      {item.speaker}
                    </span>
                  )}
                  <span className="text-xs text-stone-500 font-medium">
                    {showNumbering ? `Câu số ${item.index}` : 'Bản dịch chuẩn'}
                  </span>
                </div>

                {/* Sentence Toolbar */}
                <div className="flex items-center gap-1.5">
                  {/* Listen Pronunciation */}
                  <button
                    type="button"
                    onClick={() => handlePlaySentence(item.chinese, item.index)}
                    className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-lg text-xs font-medium transition-colors ${
                      isPlaying
                        ? 'bg-red-600 text-white animate-pulse'
                        : 'bg-white hover:bg-stone-200/60 text-stone-700 border border-stone-200'
                    }`}
                    title="Phát âm tiếng Trung chuẩn Bắc Kinh"
                  >
                    <Volume2 className="w-3.5 h-3.5" />
                    <span>{isPlaying ? 'Đang phát...' : 'Phát âm'}</span>
                  </button>

                  {/* Copy Standard 3-Part Block */}
                  <button
                    type="button"
                    onClick={() => handleCopySentence(item, item.index)}
                    className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg text-xs font-medium bg-white hover:bg-stone-200/60 text-stone-700 border border-stone-200 transition-colors"
                    title="Sao chép toàn bộ khối: Tiếng Trung - Pinyin - Tiếng Việt"
                  >
                    {isCopied ? (
                      <>
                        <Check className="w-3.5 h-3.5 text-emerald-600" />
                        <span className="text-emerald-700 font-semibold">Đã chép</span>
                      </>
                    ) : (
                      <>
                        <Copy className="w-3.5 h-3.5" />
                        <span>Chép mẫu chuẩn</span>
                      </>
                    )}
                  </button>
                </div>
              </div>

              {/* 3 Mandatory Parts Body */}
              <div className="p-5 space-y-4">
                {/* 1. Tiếng Trung */}
                <div>
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-xs font-bold uppercase tracking-wider text-red-700 flex items-center gap-1.5">
                      <span className="w-2 h-2 rounded-full bg-red-600" />
                      Tiếng Trung
                    </span>
                    <button
                      type="button"
                      onClick={() => handleCopyPart(item.chinese, `zh-${item.index}`)}
                      className="text-[11px] text-stone-400 hover:text-stone-700 transition-colors"
                    >
                      {copiedPart === `zh-${item.index}` ? 'Đã chép' : 'Chép chữ Hán'}
                    </button>
                  </div>
                  <div className="text-xl sm:text-2xl font-chinese text-stone-900 tracking-wide leading-relaxed py-1">
                    {/* Tokenized clickable words */}
                    {item.tokens && item.tokens.length > 0 ? (
                      <div className="flex flex-wrap gap-x-1.5 gap-y-1">
                        {item.tokens.map((tok, tIdx) => (
                          <span
                            key={tIdx}
                            onClick={() => onInspectWord(tok.chinese, item.chinese)}
                            className="cursor-pointer hover:text-red-700 hover:bg-red-50/80 rounded px-1 -mx-1 transition-all group relative border-b border-dashed border-transparent hover:border-red-400"
                            title={`Tra cứu "${tok.chinese}" (Pinyin: ${tok.pinyin} - Nghĩa: ${tok.meaning})`}
                          >
                            {tok.chinese}
                          </span>
                        ))}
                      </div>
                    ) : (
                      <span>{item.chinese}</span>
                    )}
                  </div>
                </div>

                {/* 2. Pinyin */}
                <div className="pt-2 border-t border-stone-100">
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-xs font-bold uppercase tracking-wider text-amber-700 flex items-center gap-1.5">
                      <span className="w-2 h-2 rounded-full bg-amber-600" />
                      Pinyin (Có đầy đủ dấu thanh)
                    </span>
                    <button
                      type="button"
                      onClick={() => handleCopyPart(item.pinyin, `py-${item.index}`)}
                      className="text-[11px] text-stone-400 hover:text-stone-700 transition-colors"
                    >
                      {copiedPart === `py-${item.index}` ? 'Đã chép' : 'Chép Pinyin'}
                    </button>
                  </div>
                  <p className="text-base sm:text-lg font-medium text-stone-800 tracking-normal font-sans py-1 selection:bg-amber-100">
                    {item.pinyin}
                  </p>
                </div>

                {/* 3. Tiếng Việt */}
                <div className="pt-2 border-t border-stone-100">
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-xs font-bold uppercase tracking-wider text-emerald-700 flex items-center gap-1.5">
                      <span className="w-2 h-2 rounded-full bg-emerald-600" />
                      Tiếng Việt
                    </span>
                    <button
                      type="button"
                      onClick={() => handleCopyPart(item.vietnamese, `vi-${item.index}`)}
                      className="text-[11px] text-stone-400 hover:text-stone-700 transition-colors"
                    >
                      {copiedPart === `vi-${item.index}` ? 'Đã chép' : 'Chép tiếng Việt'}
                    </button>
                  </div>
                  <p className="text-base sm:text-lg text-stone-900 leading-relaxed font-sans py-1">
                    {item.vietnamese}
                  </p>
                </div>

                {/* Notes (if polyphone, sandhi or disambiguation) */}
                {item.notes && (
                  <div className="pt-2.5 mt-2 border-t border-stone-100/90 flex items-start gap-2 bg-amber-50/70 p-3 rounded-xl border border-amber-200/60 text-xs text-amber-900">
                    <Info className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
                    <div>
                      <span className="font-semibold">Lưu ý ngữ âm / sắc thái: </span>
                      <span>{item.notes}</span>
                    </div>
                  </div>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
